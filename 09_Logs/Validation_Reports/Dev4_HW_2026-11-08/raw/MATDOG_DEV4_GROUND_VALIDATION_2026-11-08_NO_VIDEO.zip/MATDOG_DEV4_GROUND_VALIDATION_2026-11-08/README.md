# MATDOG 1.0.2-dev.4 — Originali della prima prova a terra (08/11/2026)

## Scopo
**VERSIONE LEGGERA SENZA VIDEO.** Il file `1000083730.mp4` è presente soltanto nello ZIP completo da 72 MB.

Questo archivio è stato assemblato dagli allegati ORIGINALI inviati dall'operatore direttamente nella chat ChatGPT. Non sono artefatti prelevati dall'ASUS né da GitHub. È un pacchetto di **evidenze della prova a terra**, distinto dalla precedente H1-RCA sulla fixture.

Il robot era **spento e scollegato dalla USB** al momento della preparazione del pacchetto. Firmware dichiarato/visibile: `1.0.2-dev.4`, build `4358f13234f9` (il binario installato era stato verificato durante l'H0 precedente). Non sono state effettuate operazioni hardware nella preparazione dell'archivio.

## Contenuti originali (bit-for-bit)
- `evidence/01_initial_entry_fault/matdog-motion-trace.json` — 30 campioni **dopo** `INITIAL_POSE_OUTSIDE_SAFE_ENTRY`, nessun comando nel buffer esportato. Contiene `FAULT`, `SAFE_OFF=8191`, torque OFF e telemetria. **Non contiene la fotografia geometrica esatta nell'istante del rifiuto**.
- `evidence/01_initial_entry_fault/1000083725.jpg` — screenshot originale della dashboard mobile: STAND150 abortito, testo di posa fuori dalla regione d'ingresso.
- `evidence/02_ground_walk100/matdog-motion-trace (1).json` — sessione dopo riaccensione: STAND150, WALK STANDARD 100, WALK STOP; 194 campioni, 3 comandi visibili, nessun fault nei campioni.
- `evidence/02_ground_walk100/1000083730.mp4` — **OMESSO in questa versione leggera.** È presente nello ZIP completo; durata ~24,94 s, 1920×1080.
- `evidence/03_ground_joystick_and_recovery/matdog-motion-trace (2).json` — joystick frontale e yaw; sequenze comando visibili 622–669, 240 campioni; nessun fault nei campioni.
- `evidence/03_ground_joystick_and_recovery/matdog-motion-trace (3).json` — prosecuzione joystick, STOP/STAND/PRONE; sequenze 629–676, 240 campioni; nessun fault nei campioni.

ATTENZIONE: le tracce `(2)` e `(3)` hanno **comandi duplicati** nel buffer cronologico (intervallo 629–669), ma i rispettivi campioni HTTP si sovrappongono solo per una porzione dell'uptime. Deduplicare per comando/sequence e per intervallo dei campioni prima di aggregare statistiche. Le tre tracce del secondo boot hanno `started_utc` identico perché appartengono alla stessa sessione dashboard: non usare quel campo come timestamp di inizio della singola esportazione. Il primo JSON si riferisce a un boot diverso (prima di KEY OFF/ON).

## Fonte e livello probatorio
- JSON: osservazioni HTTP/dashboard a cadenza di campionamento, **non** un log di ogni release servo. Le metriche cumulative richiedono differenze fra campioni consecutivi di una finestra correttamente delimitata.
- Screenshot: evidenza dell'esito visibile, non della geometria all'istante del rifiuto.
- Video: evidenza visiva della camminata, non misura calibrata di velocità, passo o stabilità su più superfici.
- Non sono inclusi `@MOTION DIAG` / `@MOTION TIMING` acquisiti contemporaneamente alla prova a terra, perché non forniti in questa chat. Le catture H1-RCA della fixture sono un'altra sessione.

## Utilizzo da Claude Code
1. Verificare integrità con `sha256sum -c MANIFEST_SHA256.txt` dalla radice dell'archivio estratto.
2. Calcolare una RCA indipendente dai JSON originali, separando fatti hardware, interpretazioni e ipotesi.
3. Archiviare in GitHub PR #67 **prima delle modifiche software**: rapporto, tabella delle tracce, checksum e, se appropriato, i JSON originali (ciascuno ~0,3–2,6 MB). Evitare duplicati se i file esistono già nel repo. Scegliere un percorso conforme alla struttura esistente di `09_Logs/Validation_Reports/`.
4. NON fare commit del video raw da ~75 MB: conservarlo sul filesystem ASUS come evidenza locale, riportarne hash, caratteristiche e nome nel rapporto; non creare URL GitHub fittizi. Se necessario, includere un singolo frame rappresentativo non sensibile, ma non spacciarlo per misura quantitativa. Verificare privacy visiva prima di pubblicare qualsiasi materiale.
5. Distinguere lo stato storico della dev.4 installata da nuove candidate offline. Mantenere PR #67 DRAFT e OPEN, nessun merge, flash o comando hardware.

## Checksum
`MANIFEST_SHA256.txt` elenca SHA256 e percorsi relativi dei CINQUE ORIGINALI. `INDEX.json` riporta metadati ricavati programmaticamente, senza inventare tempi o misure.
