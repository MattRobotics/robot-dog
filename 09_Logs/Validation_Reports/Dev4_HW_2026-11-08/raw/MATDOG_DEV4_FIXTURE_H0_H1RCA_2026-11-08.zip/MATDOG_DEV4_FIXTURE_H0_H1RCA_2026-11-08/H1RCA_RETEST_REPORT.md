# 1.0.2-dev.4 — H1-RCA retest on the fixture (operator-driven, read-only acquisition) — 2026-11-08 19:59–20:03Z

Sequence (operator, dashboard): STAND 120 → HOLD → joystick full turn in one press with two full reversals (JOYSTICK_REVERSING ×2) and automatic restarts through HEIGHT → release → STOP during WALK (×2) with STAND-from-stopped-walk recovery → WALK STANDARD 75 → WALK STOP → PRONE → PRONE_REST (torque OFF).
- **No FAULT**; every HEIGHT/PRONE_HEIGHT unwind completed (reason SLEW → ATTENUATED, never WORKSPACE in HEIGHT); exit record `PRONE_REST` (fault=0).
- **The H1 condition did not occur**: largest correction at a HEIGHT/PRONE_HEIGHT start +28.0/−44.6 mrad, foot-axis tilt 0.0295 rad < nominal strip 0.0349 rad (H1: +63.7/−66.5, 0.0696). The WALK_SETTLEs ended at ~22–28 mrad of roll. dev.3 would have passed these unwinds too: the fillet path of the fix is **not exercised on hardware** by this run (non-regression only).
- First HOLD saturated at +32.0/−33.9 mrad (`WORKSPACE`, benign, same as dev.3).
- Timing per phase (HTTP 1 Hz deltas): joystick walk 100 s 13.4 % overruns, 0.50 missed/s (dev.17: 20.1 %, 1.3/s); WALK STANDARD (75) 40 s 8.8 %, 0.32 missed/s (dev.17 WALK45/60: 9.4 %, ~0.015/s); HOLD 0.9 %, 0 missed; IDLE 0/0. Max release work 47.3 ms, max gap 49.0 ms. **Loop stack minimum 1696 B** (< 2 KB target, > 1.5 KB stop criterion). HTTP 699/699 200, late 0, busy 0.
- MOTION_TIMING (armed at PRONE): FIRST_MISS PRONE_LIFT lateness 21.9 ms (1 skipped), MAX_WORK 29.6 ms in PRONE_LIFT.
Files: h1rca/serial.log, h1rca/http.jsonl, h1rca/extracted/final_diag_timing.txt, h1rca/dashboard-trace-41.json.

## Run 2 — H1 condition reproduced on the fixture — 2026-11-08 20:07–20:09Z (dashboard trace 42)

Sequence (operator): PRONE → STAND 120 → HOLD → joystick held backward-left for a long time, opposite diagonals (backward-left ↔ forward-right) with two automatic reversals (`JOYSTICK_REVERSING`) → release → WALK STOP → PRONE → PRONE_REST.

**The fillet unwind path of the dev.4 fix is now exercised and VERIFIED HARDWARE.** Three unwinds started from a correction outside the 2° nominal strip, i.e. the H1 deadlock case of dev.3:

| Unwind | Start correction (trace 42) | Worst foot-axis tilt (strip 0.0349) | Unwind | Result |
|---|---|---|---|---|
| HEIGHT, restart after reversal 1 | +58.3/−72.4 mrad | 0.0640 → nominal strip INVALID | SLEW at ~40 mrad/s, monotonic, ~1.8 s, never WORKSPACE | WALK_JOYSTICK restarted |
| HEIGHT, restart after reversal 2 | +58.7/−73.0 mrad | 0.0645 → INVALID | SLEW ~1.8 s, monotonic | WALK_JOYSTICK restarted |
| PRONE_HEIGHT after release + settle | +55.4/−75.0 mrad | 0.0609 → INVALID | SLEW ~1.8 s, monotonic | PRONE_REST |

(Fault H1 on dev.3: +63.7/−66.5 mrad, tilt 0.0696, every step refused by `pointSafe`.) Tilts computed offline with the strip tool at source 5609369 (dev.4 + docs). Behaviour matches the bench prediction (~1.7 s from ~64 mrad, H1RCA_FIX §3/§6).

- No FAULT in the whole run (trace 42: 240 samples, 0 fault, 48 commands all HTTP 200 / ACCEPTED). Final `@MOTION DIAG` exit `PRONE_REST`, fault=0, missed 127 total.
- Timing joystick + settle 104 s: 11.5 % overruns, 56 missed (0.54/s). Max release work 47.8 ms, max gap 49.0 ms, loop stack min 1696 B (unchanged), late 0, busy 0, heap min 58 348 B. HTTP watcher 297/297 code 200.
- `MOTION_TIMING` (armed at PRONE): no FIRST_MISS; MAX_WORK 27.4 ms in PRONE_LIFT; hist work=11664,217,353,78,6,6,0,0.
- Unchanged from dev.3 (expected): WALK_SETTLE on the fixture grows the correction open-loop to ~58/−75 mrad; the HOLD after it saturates (`WORKSPACE`) until a posture command unwinds it.

Files: h1rca/dashboard-trace-42.json, h1rca/http.jsonl, h1rca/serial.log, h1rca/extracted/final_diag_timing_t42.txt. Acquisitions stopped 20:13Z (USB QUIT, "Motion untouched"; HTTP watcher stopped).
