# MATDOG dev.15 — input RCA Motion timing (2026-11-07)

Contiene 15 JSON originali della dashboard Motion, acquisiti durante la validazione hardware dev.15 del 06/11/2026, e audit video testuale. **NON** include video né sorgente firmware.

Fonte immagine installata: 1.0.1-dev.15 build 7997ad4d4497; commit sorgente locale 7997ad4 (verificare su ASUS, non confondere con main). APP SHA256 b81d3a4ffaa27a7690b196e77e7174c0cc7851563fcfd64cd3bddb40e62f9e13. Periodo 20 ms.

Le tracce sono finestre sovrapposte (non sommare delta fra file senza allineare now_ms, uptime e reboot). I massimi sono spesso cumulativi, e non attestano una specifica release senza correlazione. Analizzare prima release persa e breakdown READ/NOMINAL/COMPENSATE/CONVERT/FRAME/REST nello stesso intervallo quando telemetria disponibile.

Estrarre sul computer ASUS per uso da Claude Code. I log sono evidenze originali, non modificarli. Leggere SHA256SUMS prima dell'analisi. Non pubblicare automaticamente dati grezzi in un GitHub pubblico.
