# MATDOG dev.15 — Analisi forense video locomozione e joystick

**Sessione:** 6 novembre 2026  
**Firmware installato dichiarato/verificato nella sessione:** 1.0.1-dev.15, build `7997ad4d4497`  
**Sorgente visiva:** `1000083544.mp4` — SHA256 `0b14b26dab5e5daeda079ec58a2274ec2dd59d984698eb1b61ecaa00e95c84bb`  
**Documenti di confronto:** `matdog-motion-trace (20).json` e storico delle prove (15–22)  
**Classificazioni:** VERIFIED VIDEO = direttamente osservato nei fotogrammi; VERIFIED LOG = direttamente presente nella diagnostica; HYPOTHESIS = interpretazione da verificare.

## 1. Metodologia e limiti

- Il file contiene **16.620 fotogrammi decodificati**, durata **278,913 s** (ultimo fotogramma a PTS **278,897 s**), risoluzione **478 × 850**, video H.264, frequenza nominale 60 fps, media 59,59 fps. Il 99,39% circa degli intervalli temporali è al passo nominale di 1/60 s; 90 intervalli sono circa 2/60 s e pochi più lunghi. Per l'asse temporale si usano i **PTS effettivi**, non semplicemente l'indice del fotogramma/60.
- Ogni fotogramma è stato decodificato; è stata tracciata automaticamente la regione luminosa verde/ciano sul dorso (posizione x/y in pixel e area apparente) e misurata la variazione visiva rispetto al fotogramma precedente in una regione che comprende il robot. Segmenti e fasi sono stati poi controllati visivamente con immagini campionate più densamente.
- **Accuratezza della timeline delle azioni:** approssimativamente ±1–3 secondi ai confini dedotti visivamente. La precisione di un frame descrive l'osservazione, non l'istante di pressione del comando.
- **Non misurabili dal solo video:** latenza dall'input dashboard, velocità reale in mm/s, altezza reale in mm, modulo esatto di yaw, centro di massa, coppia, contatto piede-suolo, stabilità dinamica 3D, budget di 20 ms. La prospettiva di una camera frontale fissa e il fatto che il marker sia sul dorso impediscono di convertire i pixel in distanze fisiche senza una calibrazione di scena.
- Lo stato finale nel filmato è **eretto e immobile**. **PRONE, timeout `NATIVE_TARGET_NOT_REACHED` e rilascio anticipato della coppia non sono visibili in questo specifico video**: rimangono evidenze separate della diagnostica e dell'osservazione operatore.

## 2. Timeline video (riferimento: tempo da inizio file)

| Video | Durata indicativa | Osservazione verificabile | Interpretazione e incertezza |
|---|---:|---|---|
| `00:00–00:03` | 3 s | Corpo quasi immobile, orientato verso la camera | Postura iniziale; nessun input osservabile |
| `00:03–00:32` | 29 s | Il robot si avvicina alla camera; il marker dorsale scende nell'immagine da ~465 a ~509 px; silhouette crescente; oscillazioni laterali molto evidenti | Avanzamento; la prima oscillazione precede parte della traslazione |
| `00:32–01:00` | 28 s | Inverte l'avvicinamento; marker y scende in profondità da ~509 a ~446 px; silhouette decrescente | Arretramento osservabile, senza evidente caduta |
| `01:00–01:14` | 14 s | Passi/assestamento con deriva netta ridotta in x/y e oscillazioni residuo | Fase di transizione; impossibile distinguere con certezza un comando attivo dal completamento del gait |
| `01:14–01:49` | 35 s | Traslazione del corpo verso la **destra dello schermo**; x lenta ~280→335 px; y pressoché stabile | Strafe nel piano, senza grande componente longitudinale |
| `01:49–02:15` | 26 s | Movimento in senso laterale opposto e oscillazioni; x scende rispetto al massimo | Strafe inverso o fine/reindirizzamento dello strafe, confini approssimati |
| `02:15–02:42` | 27 s | Il corpo passa dalla vista frontale a un orientamento nettamente obliquo; muso ruota verso **destra dello schermo** | Rotazione antioraria descritta dall'operatore, evidente |
| `02:42–03:00` | 18 s | Assetto molto obliquo mantenuto/variato lentamente, zampe ancora in cicli | Impossibile separare con esattezza rotazione residua, mantenimento e transizione |
| `03:00–03:18` | 18 s | Diminuisce nettamente l'angolo apparente; frontale recuperato | Rotazione oraria di ritorno, verificata visivamente |
| `03:18–03:36` | 18 s | Postura prevalentemente frontale, ulteriori passi e traslazioni contenute | Riposizionamento/inizio altra combinazione joystick |
| `03:36–04:12` | 36 s | Il robot avanza e si sposta verso **sinistra dello schermo**; x lenta ~310→235 px, y ~438→490 px | Traslazione diagonale, coerente con componenti joystick avanti+destra nel riferimento del robot (faccia rivolta verso la camera) |
| `04:12–04:38,9` | 26,9 s | Nessun movimento corporeo rilevante, marker praticamente costante (x~234–235, y~489–490) | Postura finale eretta; video NON contiene PRONE |

**Nota sul verso:** destra/sinistra riferito allo schermo non equivale alla destra/sinistra del robot, che guarda verso l'obiettivo. Nessun verso di comando è ricostruito esclusivamente da un pixel.

## 3. Metriche estratte dai fotogrammi

### Oscillazione del corpo e cadenza

| Finestra | Periodicità visiva | Ampiezza dell'oscillazione orizzontale |
|---|---|---|
| Avanzamento `00:05–00:32` | circa 6–7 s | circa 29,7 px (intervallo 5°–95° percentile segnale detrended) |
| Arretramento `00:33–01:01` | circa 6–7 s | circa 29,7 px |
| Strafe `01:15–01:42` | **6,53 s** (picchi a 79,74 / 86,34 / 92,79 / 99,34 s) | circa 29,0 px |
| Fase rotatoria `02:13–02:40` | **6,48 s** (picchi a 137,45 / 143,93 / 150,39 / 156,89 s) | circa 31,8 px |
| Diagonale `03:35–04:10` | **6,51 s** (picchi a 219,61 / 226,18 / 232,66 / 239,17 / 245,66 s) | circa 31,3 px |

La componente periodica dominante dello spostamento del marker ha dunque **periodo ~6,5 secondi**, **frequenza ~0,154 Hz** e **circa 9,2 oscillazioni complete/minuto**. Questi sono cicli **visivi della proiezione laterale del corpo**, non una misura autonoma del periodo preciso di un piede o del ciclo interno dell'engine.

**VERIFIED VIDEO:** forte oscillazione laterale periodica mentre la progressione media è lenta; l'oscillazione rimane presente in avanti, all'indietro, nello strafe, durante il yaw e nella diagonale. Non sono osservate cadute durante la ripresa. La traiettoria nel video non è una misura di aderenza o stabilità sotto perturbazione.

**HYPOTHESIS:** una parte sostanziale del tempo del gait è investita nel trasferimento laterale del carico e nei tempi di assestamento prima dei piccoli avanzamenti dei piedi. Per dimostrare che la riduzione del sway sarebbe sicura servono margini cinematici, contatti/support polygon e confronto telemetrico per fase; il solo video non prova che lo sway sia interamente superfluo.

### Traslazioni apparenti (pixel, NON mm)

- Avanzamento: riferimento y da ~465 px a ~509 px (+44 px), area luminosa apparentemente crescente.
- Arretramento: y da ~509 px a ~446 px (−63 px), area apparente decrescente; il robot torna più lontano dalla camera rispetto al massimo avvicinamento.
- Prima traslazione laterale: riferimento x lento da ~280 a ~335 px (+55 px), y quasi invariato.
- Ultima diagonale: riferimento x lento da ~308 a ~235 px (−73 px), y da ~438 a ~490 px (+52 px).
- Inizio avanzamento: transitorio di oscillazione/leggero spostamento indietro nella proiezione intorno a `00:04–00:06` prima della progressione in avanti. Coerente con un precarico, ma non prova uno spostamento fisico del centro di massa all'indietro.

## 4. Confronto separato con diagnostica Motion (20)

Questo paragrafo riguarda **i dati del Controller**, non misure di velocità o input dedotte dal filmato. La diagnostica (20) copre una finestra di circa 83,55 s di uptime (683,445–766,996 s), con le ultime 48 richieste registrate; non contiene tutti gli input dei 279 s del video. La corrispondenza temporale precisa fra le due sorgenti non è certificata.

| Parametro | Dato verificato nella traccia (20) |
|---|---:|
| Richieste HTTP negli ultimi 48 comandi registrati | **48/48 HTTP 200**, senza 503 in questa finestra |
| Ultimi comandi proporzionali visibili | avanti 5,5 mm/s + destra 1,9 mm/s; poi avanti 4,3 mm/s + destra 2,4 mm/s |
| Rilascio joystick accettato → `STAND_REACHED` | **8.378 s** |
| STOP accettato → `STOPPED_SUPPORT_UNVERIFIED` | **1.935 s** |
| `missed_releases` nella finestra | da 946 a 1291, **+345** |
| Massimo lavoro di una release | **47,618 ms**, contro periodo nominale 20 ms |
| Max gap release | **49,434 ms** |
| Polling HTTP | 1 timeout `TIMEOUT_800MS` e 7 poll saltati |
| Stato finale tracciato | `STOPPED` / `STOPPED_SUPPORT_UNVERIFIED`; **torque ON**, non SAFE_OFF |

**Interpretazione:** il ritorno automatico alla posa è una funzione operativa validata, ma dura circa 8,4 s nella sequenza registrata, coerentemente con la lentezza segnalata dall'operatore. Il gesto di STOP è differente: il Controller ha mantenuto coppia ON poiché il supporto non era verificato; non va riportato come SAFE_OFF. Il timing a 50 Hz rimane gravemente sovraccarico nonostante l'aspetto visivo generalmente regolare del gait.

Il modulo delle temperature o delle correnti non è misurabile dal video: per RCA termica e sovraccarichi servono le tracce già archiviate.

## 5. Cosa il video dimostra e cosa NON dimostra

**VERIFIED VIDEO** — progressione avanti e indietro; strafe in due sensi; rotazione con ritorno verso la vista frontale; traslazione diagonale; ciclicità regolare e marcata dello sway; capacità di rimanere in posizione eretta al termine senza ulteriori grandi movimenti visibili.

**VERIFIED LOG (traccia 20)** — ingresso proporzionale misto accettato; rilascio accettato e completato in STAND; STOP completato; durante l'ultima finestra nessun 503 nei 48 comandi salvati; 345 nuove deadline perse e max lavoro Motion 47,618 ms.

**NOT TESTED BY THIS VIDEO** — PRONE riuscito/fallito e sicurezza del torque OFF; IMU pitch/roll su piattaforma inclinata; reale margine di stabilità, forza servo, workspace e velocità massima ottenibile. Gli eventi PRONE delle diagnostiche (15,18,22) e il nuovo fallimento riferito dall'operatore sono da conservare come prove distinte, non "risolte" dal filmato.

## 6. Priorità tecniche conseguenti

1. **PRONE e fault:** evitare rilascio prematuro della coppia sotto un corpo ancora sollevato; RCA sulla transizione intorno a 53 mm, confronto casi riusciti/falliti, e recupero supervisionato dopo fault. Non disabilitare un controllo fisico per far passare il test.
2. **Motion deadline e comunicazioni:** profilare e ridurre `COMPENSATE/HOLD` e contesa sul percorso Motion/HTTP. Il risultato visivo non equivale a 50 Hz rispettati.
3. **Gait:** dopo avere ridotto i costi di controllo, ottimizzare durata e ampiezza sway rispetto al support polygon, distanza realmente percorsa per ciclo e ritorno in STAND. Conservare proporzionalità joystick e STOP, già funzionanti.
4. **Stabilizzazione roll:** separare capacità articolare osservata durante swing dalla disponibilità in carico delle quattro zampe; non ampliare limiti solo perché un movimento di gait li raggiunge.

## 7. Artefatti e tracciabilità

- `MATDOG_DEV15_VIDEO_PER_FRAME_16620.csv`: **un record per ciascuno dei 16.620 fotogrammi**, con PTS effettivi, centro/area LED, posizione lenta, componente laterale detrended e differenza visiva di frame.
- `MATDOG_DEV15_VIDEO_TRAJECTORY.png`: grafico posizione x/y del riferimento dorsale e oscillazione orizzontale detrended.
- `MATDOG_DEV15_VIDEO_KEYFRAMES.jpg`: tavola dei fotogrammi chiave.
- Video originale: `1000083544.mp4`; conservare separatamente senza ricodifica.

**Conclusione:** il video documenta la riuscita delle funzioni locomotorie del joystick, la **lentezza oggettiva delle oscillazioni (~6,5 s/ciclo visivo)** e un trasferimento laterale ampio. Non supporta la conclusione che i limiti meccanici siano già raggiunti, né può certificare il PRONE, che richiede una RCA indipendente. La soluzione ingegneristica prioritaria è una patch mirata sul completamento PRONE e sul timing, seguita dall'ottimizzazione cinematica del gait senza eliminare le protezioni reali.
