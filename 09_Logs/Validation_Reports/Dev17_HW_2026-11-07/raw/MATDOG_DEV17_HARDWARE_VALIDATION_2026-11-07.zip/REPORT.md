# MATDOG dev.17 — hardware validation findings (2026-11-07)

## Evidence and identity
- Installed APP reported after Claude Code flash + first boot: `1.0.1-dev.17`; `build_id=17db0efe2324`; source commit `17db0efe23242ae8932b5549546a9758d9aa4645`; APP size 1,707,808 bytes; APP SHA256 `14e055a0bfa2adcab8f87df29ece0a0cf01a6e9e13b99aee1c94bda59ba84a83`.
- Flash/boot evidence is on the ASUS in `~/MATDOG/verification-artifacts/MATDOG_DEV17_FLASH_PREP_20261107/`; user-provided Claude report says a single APP-only write at 0x010000, digest verified, READY/RUN, NVS gen-1 `VALID_ACKNOWLEDGED`, census 13/13, 90+ seconds IDLE with 160/160 HTTP200 and no missed/overrun, all servo torque OFF. **This ZIP does not independently verify those ASUS files**; reconcile with originals and checksums before release.
- Source branch in GitHub PR #64; installed firmware/APP and PR HEAD are different referents; don't equate them.

## Timeline of session (VERIFIED HARDWARE unless qualified)
1. `(33)` IDLE first connection, Twin rendered, ViewCube/triad click and camera controls, STOP visible; user confirmed stable UI; observation ~54.26 s; 0 missed, 0 overruns, SAFE_OFF 8191, fault=false.
2. `(34)` STAND100 executed in 11.831 s, final estimated height ~98.6 mm, no physical instability; 0 missed and +2 overruns in sample window, HOLD had no new overruns. Intermittent display connection banner remains rare; 4 sample HTTP roundtrip observations >1000 ms (max 1680 ms), 0 recorded poll_errors. The earlier Twin graphics orientation artifact did not appear during this STAND.
3. `(35)` refresh with torque ON in HOLD worked after initial apparent delay; subsequent refreshes stable (operator). STAND125 2.875 s, STAND100 2.402 s; WALK45 and WALK60 accepted, corresponding WALK STOPs reached STAND_REACHED in 8.948 s and 8.934 s; final STANDING/HOLD, fault=false. 1 missed and 314 overruns in ~83.66 s sample window, max work 33.412 ms. User inspected front-left leg closely and reports vibration no longer present in low gait at 60 mm/cycle.
4. `(36)` STOP while WALKING and direct WALK after STOP without stand excursion reported successful by operator; **the early command sequence is no longer present in the last-48-command ring**, so do not invent timestamps/status for it. Prolonged proportional joystick with forward + lateral component observed physically working; newest 48 commands are seq 72–119, including many refreshes and seq 118 neutral release. Release seq118 `COMPLETED/STAND_REACHED` in 8.865 s; PRONE seq119 `COMPLETED/PRONE_REST` in 12.633 s; final SAFE_OFF 13/13, 0 fault. Sample window ~83.52 s has +64 missed and +491 overruns, max work 47.215 ms, stack minimum observed 2,060 bytes. Attributing all 64 missed to joystick *alone* would be overclaiming: sample window also includes walking, settle and prone; per-phase counters can be analyzed separately from raw samples. The operator confirms responsive actions and no new loss of balance.
5. End of session: robot powered OFF with BMS KEY OFF and returned to fixture (operator report). No additional hardware test requested tonight.

## HTTP telemetry caveat
- `(33)` RTT median 37.4 ms; `(34)` 46.6 ms, 4 samples >1 s, max 1.680 s; `(35)` 72.8 ms, max 189.7 ms; `(36)` 68.3 ms, max 258.3 ms **within retained samples**.
- `(35)` and `(36)` both retain the *same prior* `TIMEOUT_3500MS` poll error, not two fresh errors. `late_dropped` and `poll_skipped` are rolling cumulative counters per browser session and are not discrete transport packet loss measurements.
- No fault state and no transport.late/busy indicated in retained final snapshots; these do not rule out transient browser/network delays. Remaining TCP loss cause is UNKNOWN.

## Unclosed functional and diagnostic work (not barriers automatically to operator-scoped stable)
- Gait period 20 ms occasionally exceeded in WALK/joystick; root cause and speed optimization reserved for next development branch.
- Need a measured end-to-end STOP delay under load on a physical phone, especially cold-cache Twin initialization.
- User prefers joystick/control overlay with slight transparency **inside** 3D Twin instead of below; currently below works. This is future UX work, not a reason to modify the tested APP.
- Joystick walking has greater lateral sway than WALK button; proportional change is a future design decision needing geometric validation, not part of tested dev.17.
- PRONE displayed with rear feet apparently floating relative to Twin floor: graphic/camera/floor issue not necessarily actual foot support, tracked for later.
- IMU pitch/roll rotations, LEDs subsystem checks and maintenance RESTORE were not specifically covered in dev.17 session; LED green visual feedback improved, not a complete hardware LED qualification.

## Release recommendation
Operator has explicitly accepted this exact installed candidate as first **stable for current hardware and tested command set**. Stable GitHub Release is appropriate *as an operator-scoped, limitations-documented freeze*, not as a blanket real-time safety guarantee. Release the exact verified installed APP unchanged, with explicit source/build hash and documented limitations, preserve rollback dev.16, and keep still-relevant issues open or move them to the next milestone. No new flash or recompile for the sole purpose of changing version string.
